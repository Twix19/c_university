﻿#include <iostream>
using namespace std;

int main()
{
    int x, res;
    if (x < -2 || x>2)res = 2 * x;
    else res = -3 * x;
    cout << res;
}
