﻿#include <iostream>
#include <math.h>

int main()
{
    double x;
    std :: cin>>x;
    std::cout<< (pow(x, 2) + 1) / sqrt(pow(x, 2) + 1);
}