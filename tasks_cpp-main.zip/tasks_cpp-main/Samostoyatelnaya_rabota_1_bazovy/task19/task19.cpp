﻿#include <iostream>
#include <math.h>

int main()
{
    double a;
    std::cout << "Введите сторону: "; std::cin >> a;
    std::cout<< pow(a, 2)<<"\n"<< 4 * a*a;
}