﻿#include <iostream>

int main()
{
    double a;
    std::cin>>a;
    std::cout << 4 * a;
}
