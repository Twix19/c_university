﻿#include <iostream>
#include <cmath>

int main()
{
    double a;
    std::cout << "Введите r: "; std::cin >> a;
    std::cout<< 3.14 * a * a, 2 * 3.14 * a;
}
