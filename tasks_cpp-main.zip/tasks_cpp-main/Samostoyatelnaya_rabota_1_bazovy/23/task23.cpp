﻿#include <iostream>

int main()
{
    double m, v;
    std::cin >> m >> v;
    std::cout <<m/v;
}

