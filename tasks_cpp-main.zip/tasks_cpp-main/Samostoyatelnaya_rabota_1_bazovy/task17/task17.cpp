﻿#include <iostream>

int main()
{
    float rad;
    std::cin >> rad;
    return rad * 2.0;
}
